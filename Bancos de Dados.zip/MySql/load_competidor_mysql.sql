-- Carregar dados de CSVs do concorrente
-- Ajuste os caminhos se mover os arquivos. Ative LOCAL INFILE no cliente MySQL se necessário.

USE fiap_sapatos;

-- Opcional: criar tabelas staging para evitar conflitos com PKs
DROP TABLE IF EXISTS Stg_Produtos;
CREATE TABLE Stg_Produtos (
  Codigo INT,
  Nome VARCHAR(255),
  Modelo VARCHAR(255),
  Fabricante VARCHAR(255),
  Cor VARCHAR(255),
  Tam VARCHAR(255)
);

DROP TABLE IF EXISTS Stg_Clientes;
CREATE TABLE Stg_Clientes (
  CPF VARCHAR(11),
  Nome VARCHAR(255),
  Endereco VARCHAR(255),
  CEP VARCHAR(8),
  Email VARCHAR(255),
  Telefones VARCHAR(255)
);

-- Carrega CSVs para staging
LOAD DATA LOCAL INFILE 'c:/Users/DESKTOP/OneDrive/Desktop/IA E ML/Entrega Ivan/produtos_competidor.csv'
INTO TABLE Stg_Produtos
CHARACTER SET utf8mb4
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS
(Codigo, Nome, Modelo, Fabricante, Cor, Tam);

LOAD DATA LOCAL INFILE 'c:/Users/DESKTOP/OneDrive/Desktop/IA E ML/Entrega Ivan/clientes_competidor.csv'
INTO TABLE Stg_Clientes
CHARACTER SET utf8mb4
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS
(CPF, Nome, Endereco, CEP, Email, Telefones);

-- Deduplicação simples: insere somente novos (por PK)
INSERT INTO Produtos (Codigo, Nome, Modelo, Fabricante, Cor, Tam)
SELECT s.Codigo, s.Nome, s.Modelo, s.Fabricante, s.Cor, s.Tam
FROM Stg_Produtos s
LEFT JOIN Produtos p ON p.Codigo = s.Codigo
WHERE p.Codigo IS NULL;

INSERT INTO Clientes (CPF, Nome, Endereco, CEP, Email, Telefones)
SELECT s.CPF, s.Nome, s.Endereco, s.CEP, s.Email, s.Telefones
FROM Stg_Clientes s
LEFT JOIN Clientes c ON c.CPF = s.CPF
WHERE c.CPF IS NULL;

-- Limpeza opcional das tabelas staging
-- DROP TABLE Stg_Produtos;
-- DROP TABLE Stg_Clientes;
